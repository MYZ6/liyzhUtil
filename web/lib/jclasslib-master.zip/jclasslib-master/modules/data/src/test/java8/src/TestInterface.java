public interface TestInterface {
    public void run(int[] data);
}
